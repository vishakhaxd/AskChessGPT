#!/bin/bash
set -e

# Persist stockfish binary under /home so future deploys can skip uploading it.
if [ -f ./stockfish-linux ]; then
  chmod +x ./stockfish-linux
  mkdir -p /home/site/bin
  cp -f ./stockfish-linux /home/site/bin/stockfish-linux
  chmod +x /home/site/bin/stockfish-linux
fi

# Install packages if required by runtime environment.
if ! python -c "import flask_cors" >/dev/null 2>&1; then
  echo "[startup] Installing packages..."
  pip install --no-cache-dir --root-user-action=ignore -r /home/site/wwwroot/requirements.txt
  echo "[startup] Packages installed."
fi

echo "[startup] Starting gunicorn..."
gunicorn -w 1 --timeout 120 -b 0.0.0.0:8000 chess_api:app
